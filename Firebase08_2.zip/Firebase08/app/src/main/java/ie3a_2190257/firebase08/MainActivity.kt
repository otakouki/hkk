//ie3a YOSHII
package ie3a_2190257.firebase08

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity : AppCompatActivity() {
    var count :String? = null//カウント数用の変数定義
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //キー値"like"への参照を変数にセットしておく
        val database = FirebaseDatabase.getInstance().getReference("like")

        val userdb = FirebaseDatabase.getInstance().getReference("user")

        //レイアウトののID取得
        val count_view = findViewById<TextView>(R.id.count_view)
        //nameとpass用のEdittext
        val name= findViewById<EditText>(R.id.editTextTextPersonName)
        val pass= findViewById<EditText>(R.id.editTextTextPassword)


        //DBの値が変わると呼ばれる
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                //値を取得して表示
                count = snapshot.value as String
                count_view.text = count
            }
            //エラー時の処理
            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(applicationContext, "onCancelldが呼ばれました\n", Toast.LENGTH_SHORT).show()


            }
        })
        // データベースの参照を取得する
        val ref = database.getRef()
        //書き込みbuttonのID取得
        val buttonWrite = findViewById<Button>(R.id.button)
        //登録ボタンのID取得
        val submitbutton=findViewById<Button>(R.id.submitbutton)

        //登録ボタンのクリックイベント
        submitbutton.setOnClickListener{
            var namedata= name.text.toString()
            var passdata=pass.text.toString()
            userdb.child(namedata).setValue(passdata)
        }

        //ボタンがクリックされた時
        buttonWrite.setOnClickListener{
            var  num=count?.toIntOrNull()
            num=num?.plus(1)
            ref.setValue(num.toString())
        }
    }
}