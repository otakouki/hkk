//ie3a YOSHII
package ie3a_2190257.firebase08

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity : AppCompatActivity() {
    var count :String? = null//カウント数用の変数定義
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //キー値"like"への参照を変数にセットしておく
        val database = FirebaseDatabase.getInstance().getReference("like")
        //TextViewのID取得
        val count_view = findViewById<TextView>(R.id.count_view)

        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                count = snapshot.value as String
                count_view.text = count
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(applicationContext, "onCancelldが呼ばれました\n", Toast.LENGTH_SHORT).show()


            }
        })
        // データベースの参照を取得する
        val ref = database.getRef()
        val buttonWrite = findViewById<Button>(R.id.button)

        buttonWrite.setOnClickListener{
            var  num=count?.toIntOrNull()
            num=num?.plus(1)
            ref.setValue(num.toString())
        }
    }
}