//ie3a12 YOSHII
package ie3a_2190257.firebase08

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity : AppCompatActivity() {
    var count :String? = null//カウント数用の変数定義
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //キー値"like"と"user"への参照を変数にセットしておく
        val database = FirebaseDatabase.getInstance().getReference("like")
        val userdb = FirebaseDatabase.getInstance().getReference("user")

        //レイアウトののID取得
        val count_view = findViewById<TextView>(R.id.count_view)
        //nameとpass用のEdittext
        val name= findViewById<EditText>(R.id.editTextTextPersonName)
        val pass= findViewById<EditText>(R.id.editTextTextPassword)

        //DBの値が変わると呼ばれる
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                //値を取得して表示
                count = snapshot.value as String
                count_view.text = count
            }
            //エラー時の処理
            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(applicationContext, "onCancelldが呼ばれました\n", Toast.LENGTH_SHORT).show()
            }
        })
        // データベースの参照を取得する
        val ref = database.getRef()
        // データベースの参照を取得する
        val ref2 = userdb.getRef()
        //書き込みbuttonのID取得
        val buttonWrite = findViewById<Button>(R.id.button)
        //登録ボタンのID取得
        val submitbutton=findViewById<Button>(R.id.submitbutton)
        //ログインボタンのID取得
        val loginbutton=findViewById<Button>(R.id.loginbutton)

        //登録ボタンのクリックイベント
        submitbutton.setOnClickListener{
            var namedata= name.text.toString()
            var passdata=pass.text.toString()
            userdb.child(namedata).setValue(passdata)
        }

        //ボタンがクリックされた時
        buttonWrite.setOnClickListener{
            var  num=count?.toIntOrNull()
            num=num?.plus(1)
            ref.setValue(num.toString())
        }

        loginbutton.setOnClickListener{
            //入力値取得
            var namedata= name.text.toString()
            var passdata=pass.text.toString()

            ref2.child(namedata).addValueEventListener(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    val value = dataSnapshot.getValue(String::class.java)//valueに値が入る
                    //valueをトースト表示してみる
                    Toast.makeText(baseContext, value,
                        Toast.LENGTH_LONG).show()

                    if(value.equals(passdata)){//取得した値と入力値比較
                        val intent=Intent(this@MainActivity,SubActivity::class.java)
                        intent.putExtra("data", namedata)
                        startActivity(intent)

                    }else{
                        Toast.makeText(baseContext, "ログイン情報が間違っています",
                            Toast.LENGTH_LONG).show()

                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(baseContext, "読み込み失敗",
                        Toast.LENGTH_LONG).show()
                }
            })
        }


    }
}